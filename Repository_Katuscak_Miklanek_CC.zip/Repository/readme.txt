Content of the .zip file for the paper "What Drives Conditional Cooperation in Public Good
Games?" by Peter Katuscak and Tomas Miklanek:

1. Instructions- printed instructions for both, within- and between- subject design
2. Software- zTree programs for both, within- and between- subject design
3. Data files- two Stata datasets for both, within- and between- subject design
4. do file- containing a code that replicates all the results, figures and tables from the paper
5. Description of variables (below in this txt file)


Within-subject data variables (exact values explained in the value labels)

Variable name			     Description

session                              Session number
subject                              Subject number
order_nr                             Number of the scenario orders
group                                Group for payments
profit                               Money earned
sim_own                              Last value in the simulator, own
sim1                                 Last simulator value for player1
sim2                                 Last simulator value for player2
sim3                                 Last simulator value for player3
sim_count                            Number of clicks in simulator
int_sim_own                          initial value in simulator, own
int_sim1                             initial value in simulator, player1
int_sim2                             initial value in simulator, player2
int_sim3                             initial value in simulator, player3
unc                                  Scenario 1 contribution
s2con0 - 10                          Scenario 2 contribution, for values 0-10
s3con0 - 10                          Scenario 3 contribution, for values 0-10
s4con0 - 10                          Scenario 4 contribution, for values 0-10
s5con0 - 10                          Scenario 5 contribution, for values 0-10
drawround                            Payoff relevant round
gender                    	     Female=1
age                                  
country             		    Country
siblings                             Number of siblings
field               		     Field      
degree              		   Degree     
pay_own                              Own contribution in PR scenario
earn                              Earnings in points
er                                   exchange rate
fix                                  fixed fee
pay_other                            sum of payments from non-cc if you are cc
cc                                   conditional contributor
rand1sc5                             random draw for player 1 if scenario5
rand2sc5                             random draw for player 2 if scenario5
rand3sc5                             random draw for player 3 if scenario5
confused                             Subject appears to be confused
cctype              		  Conditional cooperator type
CC                                   Conditional cooperator
UC                                   Unconditional cooperator
FR                                   Free rider
TC                                   Triangle cooperator
ID                              unique identifier
first_sc                        Number of the first randomized scenario
disp1                                1st diplayed sc
disp2                                2nd diplayed sc
disp3                                3rd diplayed sc
disp4                                4th diplayed sc

Between-subject data variables (exact values explained in the value labels)

Variable name			     Description

session                              Session number
subject                              Subject number
treatment                            
q1_wrong                             Number of incorrect questions in Scenario 1 quiz
q2_wrong                             Number of incorrect questions in Scenario 2 quiz
q_total                              Number of incorrect questions in both scenarios
group                                Group
profit                                Profit
sim_own                              Last value in the simulator, own
sim1                                 Last simulator value for player1
sim2                                 Last simulator value for player2
sim3                                 Last simulator value for player3
sim_count                            Number of clicks in simulator
int_sim_own                          initial value in simulator, own
int_sim1                             initial value in simulator, player1
int_sim2                             initial value in simulator, player2
int_sim3                             initial value in simulator, player3                        
unc                                  Scenario 1 contribution                                  
s2con0 - 10                          Scenario 2 contribution, for values 0-10
relsc                                Payoff relevant round
gender                    	     Female=1
age                                  
country             		    Country
siblings                             Number of siblings
field               		     Field      
degree              		   Degree     
pay_own                              Own contribution in PR scenario
earn                              Earnings in points
er                                   exchange rate
fix                                  fixed fee
pay_other                            sum of payments from non-cc if you are cc
cc                                   conditional contributor
rand1sc5                             random draw for player 1 if scenario5
rand2sc5                             random draw for player 2 if scenario5
rand3sc5                             random draw for player 3 if scenario5                   
